import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const backgroundSource = await readFile(new URL("../background.js", import.meta.url), "utf8");
const completionStart = backgroundSource.indexOf("async function completeTask");
const completionEnd = backgroundSource.indexOf("function characterMessagePayload", completionStart);
const completionSource = backgroundSource.slice(completionStart, completionEnd);

test("background rejects a scene completion without every requested image URL", () => {
  assert.match(completionSource, /verifiedAssets\.length < expectedImages/);
  assert.match(completionSource, /scheduleSceneAutomaticRetry/);
  assert.match(completionSource, /다운로드 가능한 결과 이미지/);
});

import {
  MIN_DELAY_MS,
  QUEUE_ALARM,
  STATE_KEY,
  applyRegisteredCharacterKeys,
  carryForwardCompletedTasks,
  createCharacters,
  createInitialState,
  createJobs,
  findNextTask,
  hasPendingTasks,
  hydrateState,
  isBlockingFlowError,
  normalizeOptions,
  prepareSceneAutomaticRetry,
  prepareSceneNavigationRecovery,
  rollbackUnverifiedCompletedScenes,
  retryFailedTasks,
  setCharacterReady,
  setJobReady
} from "./lib/queue-state.js";
import {
  buildDownloadManifest,
  uniqueAssets
} from "./lib/download-manifest.js";
import { requireArchiveResult } from "./lib/archive-result.js";

let stateMutation = Promise.resolve();
let launchInProgress = false;
let downloadInProgress = false;

function shouldKeepDisplayAwake(state) {
  return downloadInProgress
    || Boolean(state?.activeJobId)
    || ["running", "waiting", "pausing"].includes(String(state?.status || ""));
}

function syncPowerState(state) {
  if (shouldKeepDisplayAwake(state)) {
    chrome.power.requestKeepAwake("display");
  } else {
    chrome.power.releaseKeepAwake();
  }
}

async function readState() {
  const stored = await chrome.storage.local.get(STATE_KEY);
  return hydrateState(stored[STATE_KEY]);
}

function broadcastState(state) {
  chrome.runtime.sendMessage({ type: "STATE_UPDATED", state }).catch(() => {});
}

function updateState(mutator) {
  const operation = stateMutation.then(async () => {
    const state = await readState();
    await mutator(state);
    state.revision = Number(state.revision || 0) + 1;
    state.updatedAt = Date.now();
    await chrome.storage.local.set({ [STATE_KEY]: state });
    syncPowerState(state);
    broadcastState(state);
    return state;
  });
  stateMutation = operation.catch(() => {});
  return operation;
}

function isFlowUrl(url) {
  return /^https:\/\/labs\.google\/fx\/(?:[^/]+\/)?tools\/flow(?:\/|$)/i.test(String(url || ""));
}

async function findFlowTab(preferredTabId) {
  if (preferredTabId != null) {
    try {
      const preferred = await chrome.tabs.get(preferredTabId);
      if (isFlowUrl(preferred.url)) return preferred;
    } catch {
      // The stored tab may have been closed.
    }
  }

  const activeTabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const activeFlow = activeTabs.find((tab) => isFlowUrl(tab.url));
  if (activeFlow) return activeFlow;

  const flowTabs = await chrome.tabs.query({ url: "https://labs.google/fx/*" });
  return flowTabs
    .filter((tab) => isFlowUrl(tab.url))
    .sort((a, b) => Number(b.lastAccessed || 0) - Number(a.lastAccessed || 0))[0] || null;
}

async function sendToTab(tabId, message) {
  try {
    return await chrome.tabs.sendMessage(tabId, message);
  } catch (error) {
    const noReceiver = /Receiving end does not exist|Could not establish connection/i.test(String(error?.message || error));
    if (!noReceiver) throw error;
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
    return chrome.tabs.sendMessage(tabId, message);
  }
}

async function dispatchTextFallback(target, text) {
  for (const character of Array.from(text)) {
    if (character === "\n") {
      await chrome.debugger.sendCommand(target, "Input.dispatchKeyEvent", {
        type: "rawKeyDown",
        key: "Enter",
        code: "Enter",
        windowsVirtualKeyCode: 13,
        nativeVirtualKeyCode: 13
      });
      await chrome.debugger.sendCommand(target, "Input.dispatchKeyEvent", {
        type: "keyUp",
        key: "Enter",
        code: "Enter",
        windowsVirtualKeyCode: 13,
        nativeVirtualKeyCode: 13
      });
      continue;
    }
    await chrome.debugger.sendCommand(target, "Input.dispatchKeyEvent", {
      type: "char",
      key: character,
      text: character,
      unmodifiedText: character
    });
  }
}

async function withFlowDebugger(tabId, operation) {
  if (!Number.isInteger(tabId)) throw new Error("Flow 탭을 확인할 수 없습니다.");
  const tab = await chrome.tabs.get(tabId);
  if (!isFlowUrl(tab.url)) throw new Error("신뢰 입력은 Google Flow 탭에서만 사용할 수 있습니다.");

  const target = { tabId };
  let attached = false;
  try {
    await chrome.debugger.attach(target, "1.3");
    attached = true;
    return await operation(target);
  } catch (error) {
    const message = String(error?.message || error);
    if (/another debugger|already attached|debugger is already/i.test(message)) {
      throw new Error("Flow 탭에 DevTools 또는 다른 디버거가 연결되어 있습니다. 해당 창을 닫은 뒤 재시도해 주세요.");
    }
    throw new Error(`Flow 실제 조작 전달에 실패했습니다: ${message}`);
  } finally {
    if (attached) await chrome.debugger.detach(target).catch(() => {});
  }
}

async function insertTrustedText(tabId, text, { clear = false } = {}) {
  if (typeof text !== "string" || text.length > 50_000) throw new Error("입력할 프롬프트가 올바르지 않거나 너무 깁니다.");
  return withFlowDebugger(tabId, async (target) => {
    if (clear) {
      await chrome.debugger.sendCommand(target, "Input.dispatchKeyEvent", {
        type: "rawKeyDown",
        key: "a",
        code: "KeyA",
        modifiers: 4,
        windowsVirtualKeyCode: 65,
        nativeVirtualKeyCode: 65
      });
      await chrome.debugger.sendCommand(target, "Input.dispatchKeyEvent", {
        type: "keyUp",
        key: "a",
        code: "KeyA",
        modifiers: 4,
        windowsVirtualKeyCode: 65,
        nativeVirtualKeyCode: 65
      });
      await chrome.debugger.sendCommand(target, "Input.dispatchKeyEvent", {
        type: "rawKeyDown",
        key: "Backspace",
        code: "Backspace",
        windowsVirtualKeyCode: 8,
        nativeVirtualKeyCode: 8
      });
      await chrome.debugger.sendCommand(target, "Input.dispatchKeyEvent", {
        type: "keyUp",
        key: "Backspace",
        code: "Backspace",
        windowsVirtualKeyCode: 8,
        nativeVirtualKeyCode: 8
      });
    }

    if (text) {
      try {
        await chrome.debugger.sendCommand(target, "Input.insertText", { text });
      } catch {
        await dispatchTextFallback(target, text);
      }
    }
    return { inserted: text.length, cleared: Boolean(clear) };
  });
}

async function pressTrustedKey(tabId, key) {
  if (key !== "@") throw new Error("허용되지 않은 Flow 특수 키 입력입니다.");
  return withFlowDebugger(tabId, async (target) => {
    await chrome.debugger.sendCommand(target, "Input.dispatchKeyEvent", {
      type: "rawKeyDown",
      key: "Shift",
      code: "ShiftLeft",
      modifiers: 8,
      windowsVirtualKeyCode: 16,
      nativeVirtualKeyCode: 56,
      location: 1
    });
    await chrome.debugger.sendCommand(target, "Input.dispatchKeyEvent", {
      type: "keyDown",
      key: "@",
      code: "Digit2",
      modifiers: 8,
      text: "@",
      unmodifiedText: "2",
      windowsVirtualKeyCode: 50,
      nativeVirtualKeyCode: 19
    });
    await chrome.debugger.sendCommand(target, "Input.dispatchKeyEvent", {
      type: "keyUp",
      key: "@",
      code: "Digit2",
      modifiers: 8,
      windowsVirtualKeyCode: 50,
      nativeVirtualKeyCode: 19
    });
    await chrome.debugger.sendCommand(target, "Input.dispatchKeyEvent", {
      type: "keyUp",
      key: "Shift",
      code: "ShiftLeft",
      modifiers: 0,
      windowsVirtualKeyCode: 16,
      nativeVirtualKeyCode: 56,
      location: 1
    });
    return { pressed: key };
  });
}

async function clickTrustedPoint(tabId, x, y) {
  if (!Number.isFinite(x) || !Number.isFinite(y) || x < 0 || y < 0) {
    throw new Error("클릭할 Flow 화면 좌표가 올바르지 않습니다.");
  }
  return withFlowDebugger(tabId, async (target) => {
    const point = { x: Math.round(x), y: Math.round(y) };
    await chrome.debugger.sendCommand(target, "Input.dispatchMouseEvent", {
      type: "mouseMoved",
      ...point
    });
    await chrome.debugger.sendCommand(target, "Input.dispatchMouseEvent", {
      type: "mousePressed",
      ...point,
      button: "left",
      buttons: 1,
      clickCount: 1
    });
    await chrome.debugger.sendCommand(target, "Input.dispatchMouseEvent", {
      type: "mouseReleased",
      ...point,
      button: "left",
      buttons: 0,
      clickCount: 1
    });
    return { clicked: true, ...point };
  });
}

function getTaskCollection(state, taskType) {
  return taskType === "character" ? state.characters : state.jobs;
}

function findTask(state, taskId, taskType = state.activeTaskType) {
  return getTaskCollection(state, taskType).find((entry) => entry.id === taskId) || null;
}

async function pauseWithError(message, taskId = null, taskType = null) {
  await chrome.alarms.clear(QUEUE_ALARM);
  return updateState((state) => {
    const activeId = taskId || state.activeJobId;
    const activeType = taskType || state.activeTaskType || "scene";
    const task = findTask(state, activeId, activeType);
    const rolledBack = activeType === "scene" && /(?:일일\s*한도|quota|limit reached|generation limit)/i.test(String(message || ""))
      ? rollbackUnverifiedCompletedScenes(state, activeId, message)
      : [];
    const resolvedMessage = rolledBack.length
      ? `${message} 결과 이미지가 없던 직전 ${rolledBack.length}개 완료 작업도 재생성 대기로 되돌렸습니다.`
      : message;
    if (task && task.status !== "completed") {
      task.status = "failed";
      task.stage = "확인 필요";
      task.progress = Math.min(95, Number(task.progress || 0));
      task.error = resolvedMessage;
    }
    state.activeJobId = null;
    state.activeTaskType = null;
    state.nextRunAt = null;
    state.pauseRequested = false;
    state.status = "paused";
    state.lastError = resolvedMessage;
  });
}

async function scheduleSceneAutomaticRetry(message, jobId = null) {
  if (isBlockingFlowError(message)) return pauseWithError(message, jobId, "scene");

  await chrome.alarms.clear(QUEUE_ALARM);
  const state = await updateState((draft) => {
    const activeId = jobId || draft.activeJobId;
    const job = draft.jobs.find((entry) => entry.id === activeId);
    if (!job || job.status === "completed") return;
    if (!draft.activeJobId && job.status === "pending" && draft.status === "waiting" && Number(draft.nextRunAt || 0) > Date.now()) {
      return;
    }

    if (draft.pauseRequested || draft.manualPause) {
      job.status = "pending";
      job.stage = "사용자 중단";
      job.error = null;
      draft.activeJobId = null;
      draft.activeTaskType = null;
      draft.pauseRequested = false;
      draft.manualPause = true;
      draft.status = "paused";
      draft.nextRunAt = null;
      draft.lastError = null;
      return;
    }

    const retry = prepareSceneAutomaticRetry(job, message);
    draft.activeJobId = null;
    draft.activeTaskType = null;
    draft.pauseRequested = false;
    draft.manualPause = false;
    draft.status = "waiting";
    draft.nextRunAt = Date.now() + retry.delayMs;
    draft.lastError = null;
  });

  if (state.status === "waiting" && state.nextRunAt) {
    await chrome.alarms.create(QUEUE_ALARM, { when: state.nextRunAt });
  }
  return state;
}

async function launchNextJob() {
  if (launchInProgress) return;
  launchInProgress = true;
  let selectedTask = null;

  try {
    const state = await updateState((draft) => {
      if (draft.status !== "running" || draft.activeJobId) return;
      const next = findNextTask(draft);
      if (!next) {
        const blockedByCharacter = draft.jobs.some((job) => job.status === "pending")
          && draft.characters.some((character) => character.status !== "completed");
        draft.status = blockedByCharacter ? "paused" : (draft.jobs.length || draft.characters.length ? "completed" : "idle");
        if (blockedByCharacter) draft.lastError = "모든 캐릭터 등록을 완료해야 장면 생성을 시작할 수 있습니다.";
        draft.nextRunAt = null;
        return;
      }

      const resumeSubmitted = next.type === "scene" && Boolean(next.item.requestSubmittedAt);
      selectedTask = { id: next.item.id, type: next.type, resumeSubmitted };
      draft.activeJobId = next.item.id;
      draft.activeTaskType = next.type;
      draft.phase = next.type === "character" ? "characters" : "scenes";
      draft.nextRunAt = null;
      next.item.status = resumeSubmitted ? "generating" : "configuring";
      next.item.stage = resumeSubmitted ? "기존 생성 상태 추적 재개 중" : "Flow 연결 중";
      next.item.progress = resumeSubmitted ? Math.max(28, Number(next.item.progress || 0)) : 5;
      next.item.attempts += 1;
      next.item.startedAt = Date.now();
      next.item.completedAt = null;
      next.item.error = null;
      if (next.type === "scene" && !resumeSubmitted) {
        next.item.generationMode = "direct";
        next.item.generationPercentages = [];
        next.item.baselineMedia = [];
        next.item.baselineCapturedAt = null;
        next.item.baselineFailureCount = null;
        next.item.requestSubmittedAt = null;
        next.item.recoveryAttempts = 0;
        next.item.lastRecoveryAt = null;
      }
    });

    if (!selectedTask) return;
    const task = findTask(state, selectedTask.id, selectedTask.type);
    const tab = await findFlowTab(state.tabId);
    if (!tab?.id) {
      await updateState((draft) => {
        const active = findTask(draft, selectedTask.id, selectedTask.type);
        if (active) {
          active.status = "pending";
          active.stage = "Flow 탭 필요";
          active.progress = 0;
        }
        draft.activeJobId = null;
        draft.activeTaskType = null;
        draft.status = "paused";
        draft.lastError = "Google Flow 프로젝트 탭을 연 뒤 이어하기를 눌러 주세요.";
      });
      return;
    }

    await updateState((draft) => {
      draft.tabId = tab.id;
      draft.flowConnected = true;
      const active = findTask(draft, selectedTask.id, selectedTask.type);
      if (active) {
        active.stage = selectedTask.type === "character"
          ? "캐릭터 생성 화면 준비 중"
          : selectedTask.resumeSubmitted ? "모든 미디어에서 기존 생성 결과 확인 중" : "모든 미디어 일반 생성 준비 중";
        active.progress = selectedTask.resumeSubmitted ? Math.max(28, Number(active.progress || 0)) : 10;
      }
    });

    const response = selectedTask.type === "character"
      ? await sendToTab(tab.id, {
        type: "RUN_FLOW_CHARACTER",
        character: {
          id: task.id,
          key: task.key,
          displayName: task.displayName,
          description: task.description,
          prompt: task.prompt
        },
        options: state.options
      })
      : await sendToTab(tab.id, selectedTask.resumeSubmitted
        ? {
          type: "RECONCILE_FLOW_JOB",
          job: sceneMessagePayload(task),
          options: state.options
        }
        : {
          type: "RUN_FLOW_JOB",
          job: sceneMessagePayload(task),
          options: state.options
        });

    if (!response?.accepted) {
      throw new Error(response?.error || "Flow 페이지가 작업을 시작하지 못했습니다.");
    }
  } catch (error) {
    const message = String(error?.message || error);
    if (selectedTask?.type === "scene") await scheduleSceneAutomaticRetry(message, selectedTask.id);
    else await pauseWithError(message, selectedTask?.id, selectedTask?.type);
  } finally {
    launchInProgress = false;
  }
}

async function completeTask(taskId, taskType, imagesGenerated, assets = []) {
  if (taskType === "scene") {
    const snapshot = await readState();
    const task = findTask(snapshot, taskId, taskType);
    const verifiedAssets = uniqueAssets([...(task?.resultAssets || []), ...(Array.isArray(assets) ? assets : [])]);
    const expectedImages = Math.max(1, Number(snapshot.options.imagesPerPrompt || 2));
    if (verifiedAssets.length < expectedImages) {
      return scheduleSceneAutomaticRetry(
        `Flow 완료 신호를 받았지만 다운로드 가능한 결과 이미지는 ${verifiedAssets.length}/${expectedImages}장입니다.`,
        taskId
      );
    }
  }
  await chrome.alarms.clear(QUEUE_ALARM);
  const state = await updateState((draft) => {
    if (draft.activeJobId !== taskId || draft.activeTaskType !== taskType) return;
    const task = findTask(draft, taskId, taskType);
    if (!task) return;

    task.status = "completed";
    task.stage = taskType === "character" ? `@${task.key} 등록 완료` : "완료";
    task.progress = 100;
    task.completedAt = Date.now();
    if (taskType === "character") {
      task.referenceImages = Math.max(1, Number(imagesGenerated || 1));
      task.resultAssets = uniqueAssets([...(task.resultAssets || []), ...assets]).slice(0, 1);
    }
    else {
      task.imagesGenerated = Math.max(0, Number(imagesGenerated || draft.options.imagesPerPrompt));
      task.resultAssets = uniqueAssets([...(task.resultAssets || []), ...assets]).slice(0, draft.options.imagesPerPrompt);
      task.generationPercentages = [];
      task.baselineMedia = [];
      task.baselineCapturedAt = null;
      task.baselineFailureCount = null;
      task.requestSubmittedAt = null;
      task.recoveryAttempts = 0;
      task.lastRecoveryAt = null;
      task.autoRetryCount = 0;
      task.lastRetryAt = null;
      task.lastTransientError = null;
    }
    task.error = null;
    draft.activeJobId = null;
    draft.activeTaskType = null;
    draft.lastError = null;

    if (!hasPendingTasks(draft)) {
      draft.pauseRequested = false;
      draft.status = "completed";
      draft.phase = "completed";
      draft.nextRunAt = null;
    } else if (draft.pauseRequested) {
      draft.pauseRequested = false;
      draft.status = "paused";
      draft.nextRunAt = null;
    } else {
      draft.status = "waiting";
      draft.nextRunAt = Date.now() + Math.max(MIN_DELAY_MS, draft.options.delayMs);
    }
  });

  if (state.status === "waiting" && state.nextRunAt) {
    await chrome.alarms.create(QUEUE_ALARM, { when: state.nextRunAt });
  }
}

function characterMessagePayload(character) {
  return {
    id: character.id,
    key: character.key,
    displayName: character.displayName,
    description: character.description,
    prompt: character.prompt
  };
}

function sceneMessagePayload(job) {
  return {
    id: job.id,
    prompt: job.prompt,
    title: job.title,
    characterRefs: job.characterRefs,
    script: job.script,
    progress: job.progress,
    generationMode: job.generationMode || "direct",
    baselineMedia: Array.isArray(job.baselineMedia) ? job.baselineMedia : [],
    baselineCapturedAt: job.baselineCapturedAt || null,
    baselineFailureCount: Number.isInteger(job.baselineFailureCount) ? job.baselineFailureCount : null,
    requestSubmittedAt: job.requestSubmittedAt || null
  };
}

async function reconcileActiveCharacter(tabId, state) {
  if (state.activeTaskType !== "character" || !state.activeJobId) return;
  const character = state.characters.find((entry) => entry.id === state.activeJobId);
  if (!character) return;
  try {
    const response = await sendToTab(tabId, {
      type: "RECONCILE_FLOW_CHARACTER",
      character: characterMessagePayload(character),
      options: state.options
    });
    if (!response?.accepted) throw new Error(response?.error || "캐릭터 등록 상태 복구를 시작하지 못했습니다.");
  } catch (error) {
    await pauseWithError(
      `Flow 화면 전환 후 캐릭터 상태를 복구하지 못했습니다: ${String(error?.message || error)}`,
      character.id,
      "character"
    );
  }
}

async function reconcileActiveScene(tabId, state, deliveryAttempt = 0) {
  if (state.activeTaskType !== "scene" || !state.activeJobId) return;
  const job = state.jobs.find((entry) => entry.id === state.activeJobId);
  if (!job) return;
  try {
    const response = await sendToTab(tabId, {
      type: "RECONCILE_FLOW_JOB",
      job: sceneMessagePayload(job),
      options: state.options
    });
    if (!response?.accepted) throw new Error(response?.error || "일반 이미지 생성 상태 복구를 시작하지 못했습니다.");
  } catch (error) {
    const latest = await updateState((draft) => {
      if (draft.activeTaskType !== "scene" || draft.activeJobId !== job.id) return;
      const active = draft.jobs.find((entry) => entry.id === job.id);
      if (!active || active.status === "completed") return;
      active.status = active.requestSubmittedAt ? "generating" : "configuring";
      active.stage = `Flow 재연결 중 · 상태 확인 재시도 ${deliveryAttempt + 1}`;
      active.error = null;
      active.lastHeartbeatAt = Date.now();
      draft.status = "running";
      draft.lastError = null;
    });
    if (deliveryAttempt < 4 && latest.activeTaskType === "scene" && latest.activeJobId === job.id) {
      await new Promise((resolve) => setTimeout(resolve, 1_500 * (deliveryAttempt + 1)));
      const current = await readState();
      if (current.activeTaskType === "scene" && current.activeJobId === job.id) {
        return reconcileActiveScene(tabId, current, deliveryAttempt + 1);
      }
    }
  }
}

async function synchronizeFlowCharacters() {
  const current = await readState();
  if (current.activeJobId || ["running", "waiting", "pausing"].includes(current.status)) {
    throw new Error("실행 중인 큐를 먼저 중단한 뒤 Flow 상태를 동기화해 주세요.");
  }
  if (!current.characters.length) {
    return { state: current, registeredKeys: [], matchedKeys: [], surface: null };
  }

  const tab = await findFlowTab(current.tabId);
  if (!tab?.id) throw new Error("Flow 캐릭터 상태를 확인할 프로젝트 탭이 없습니다.");
  const scan = await sendToTab(tab.id, {
    type: "SCAN_FLOW_CHARACTERS",
    characterKeys: current.characters.map((character) => character.key)
  });
  if (!scan?.ready) throw new Error(scan?.error || "Flow 캐릭터 목록을 읽지 못했습니다.");
  if (scan.inProgress) {
    throw new Error("Flow에서 캐릭터 생성이 진행 중입니다. 완료될 때까지 현재 화면을 유지해 주세요.");
  }

  let matchedKeys = [];
  const state = await updateState((draft) => {
    matchedKeys = applyRegisteredCharacterKeys(draft, scan.registeredKeys || []);
    const scannedAssets = new Map(
      (scan.characterAssets || []).map((asset) => [String(asset.name || "").trim().toLowerCase(), asset])
    );
    for (const character of draft.characters) {
      const asset = scannedAssets.get(String(character.key || "").trim().toLowerCase());
      if (asset) character.resultAssets = uniqueAssets([asset]).slice(0, 1);
    }
    draft.tabId = tab.id;
    draft.flowConnected = true;
    draft.flowSurface = String(scan.surface || "unknown");
    draft.lastFlowSyncAt = Date.now();
    draft.lastFlowRegisteredKeys = Array.isArray(scan.registeredKeys) ? scan.registeredKeys.map(String) : [];
    if (draft.characters.some((character) => character.status === "pending")) {
      draft.phase = "characters";
    } else if (draft.jobs.some((job) => job.status === "pending")) {
      draft.phase = "scenes";
    }
    if (matchedKeys.length && /새로고침|캐릭터.*실패|등록 상태/i.test(String(draft.lastError || ""))) {
      draft.lastError = null;
    }
  });

  return {
    state,
    registeredKeys: Array.isArray(scan.registeredKeys) ? scan.registeredKeys : [],
    matchedKeys,
    surface: scan.surface || "unknown"
  };
}

async function handleFlowEvent(message, sender) {
  const tabId = sender.tab?.id ?? null;

  if (message.type === "FLOW_TRUSTED_TYPE") {
    if (!tabId || !isFlowUrl(sender.url || sender.tab?.url)) {
      throw new Error("Google Flow 콘텐츠에서 보낸 입력 요청만 허용됩니다.");
    }
    return insertTrustedText(tabId, String(message.text || ""), { clear: Boolean(message.clear) });
  }

  if (message.type === "FLOW_TRUSTED_KEY") {
    if (!tabId || !isFlowUrl(sender.url || sender.tab?.url)) {
      throw new Error("Google Flow 콘텐츠에서 보낸 키 입력 요청만 허용됩니다.");
    }
    return pressTrustedKey(tabId, String(message.key || ""));
  }

  if (message.type === "FLOW_TRUSTED_CLICK") {
    if (!tabId || !isFlowUrl(sender.url || sender.tab?.url)) {
      throw new Error("Google Flow 콘텐츠에서 보낸 클릭 요청만 허용됩니다.");
    }
    return clickTrustedPoint(tabId, Number(message.x), Number(message.y));
  }

  if (message.type === "FLOW_READY") {
    let shouldReconcileCharacter = false;
    let shouldReconcileScene = false;
    const state = await updateState((state) => {
      const sessionChanged = state.pageSessionId && state.pageSessionId !== message.pageSessionId;
      const active = state.activeJobId ? findTask(state, state.activeJobId) : null;
      if (sessionChanged && active && ["configuring", "generating"].includes(active.status)) {
        if (state.activeTaskType === "character") {
          active.status = "generating";
          active.stage = "Flow 화면 전환 · 등록 상태 복구 중";
          active.progress = Math.max(30, Number(active.progress || 0));
          active.error = null;
          active.lastHeartbeatAt = Date.now();
          state.status = "running";
          state.lastError = null;
          shouldReconcileCharacter = true;
        } else {
          prepareSceneNavigationRecovery(active);
          state.status = "running";
          state.lastError = null;
          shouldReconcileScene = true;
        }
      }
      if (!active && message.generationFailureMessage) {
        const rolledBack = rollbackUnverifiedCompletedScenes(state, null, message.generationFailureMessage);
        if (rolledBack.length) {
          const firstFailedJob = state.jobs.find((job) => job.id === rolledBack[0]);
          if (firstFailedJob) {
            firstFailedJob.status = "failed";
            firstFailedJob.stage = "일일 한도 확인 필요";
            firstFailedJob.error = message.generationFailureMessage;
          }
          state.status = "paused";
          state.phase = "scenes";
          state.nextRunAt = null;
          state.lastError = `${message.generationFailureMessage} 결과 이미지가 없던 최근 ${rolledBack.length}개 완료 작업을 재생성 대기로 되돌렸습니다.`;
        }
      }
      state.tabId = tabId;
      state.pageSessionId = message.pageSessionId;
      state.flowConnected = true;
    });
    if (shouldReconcileCharacter && tabId) void reconcileActiveCharacter(tabId, state);
    if (shouldReconcileScene && tabId) void reconcileActiveScene(tabId, state);
    return state;
  }

  if (message.type === "FLOW_JOB_PROGRESS") {
    return updateState((state) => {
      if (state.activeJobId !== message.jobId || state.activeTaskType !== "scene") return;
      const job = state.jobs.find((entry) => entry.id === message.jobId);
      if (!job || job.status === "completed") return;
      job.status = message.phase === "configuring" ? "configuring" : "generating";
      job.stage = String(message.stage || job.stage);
      job.progress = Math.max(job.progress, Math.min(96, Number(message.progress || 0)));
      job.detectedImages = Math.max(Number(job.detectedImages || 0), Number(message.detectedImages || 0));
      if (Array.isArray(message.generationPercentages)) {
        job.generationPercentages = message.generationPercentages
          .map(Number)
          .filter(Number.isFinite)
          .map((value) => Math.max(0, Math.min(100, value)))
          .slice(0, state.options.imagesPerPrompt);
      }
      if (Array.isArray(message.baselineMedia)) {
        job.baselineMedia = message.baselineMedia.map(String);
        job.baselineCapturedAt = Number(message.baselineCapturedAt || Date.now());
      }
      if (Number.isInteger(message.baselineFailureCount)) {
        job.baselineFailureCount = Math.max(0, message.baselineFailureCount);
      }
      if (message.requestSubmittedAt) job.requestSubmittedAt = Number(message.requestSubmittedAt);
      if (message.generationMode) job.generationMode = String(message.generationMode);
      job.lastHeartbeatAt = Date.now();
      state.flowConnected = true;
      state.tabId = tabId;
    });
  }

  if (message.type === "FLOW_JOB_COMPLETED") {
    return completeTask(message.jobId, "scene", message.imagesGenerated, message.assets);
  }

  if (message.type === "FLOW_CHARACTER_PROGRESS") {
    return updateState((state) => {
      if (state.activeJobId !== message.characterId || state.activeTaskType !== "character") return;
      const character = state.characters.find((entry) => entry.id === message.characterId);
      if (!character || character.status === "completed") return;
      character.status = message.phase === "configuring" ? "configuring" : "generating";
      character.stage = String(message.stage || character.stage);
      character.progress = Math.max(character.progress, Math.min(96, Number(message.progress || 0)));
      character.detectedImages = Math.max(Number(character.detectedImages || 0), Number(message.detectedImages || 0));
      character.lastHeartbeatAt = Date.now();
      state.flowConnected = true;
      state.tabId = tabId;
    });
  }

  if (message.type === "FLOW_CHARACTER_COMPLETED") {
    return completeTask(message.characterId, "character", message.referenceImages, message.assets);
  }

  if (message.type === "FLOW_CHARACTER_NEEDS_REVIEW") {
    await chrome.alarms.clear(QUEUE_ALARM);
    return updateState((state) => {
      if (state.activeJobId !== message.characterId || state.activeTaskType !== "character") return;
      const character = state.characters.find((entry) => entry.id === message.characterId);
      if (!character) return;
      character.status = "review";
      character.stage = "Flow에서 이미지 선택·이름 저장 필요";
      character.progress = Math.max(85, Number(character.progress || 0));
      character.detectedImages = Math.max(Number(character.detectedImages || 0), Number(message.referenceImages || 0));
      state.status = "paused";
      state.pauseRequested = false;
      state.nextRunAt = null;
      state.lastError = `Flow에서 참조 이미지 1~2장을 선택하고 캐릭터 이름을 '${character.key}'로 저장한 뒤 등록 확인을 눌러 주세요.`;
    });
  }

  if (message.type === "FLOW_JOB_PAUSED") {
    await chrome.alarms.clear(QUEUE_ALARM);
    return updateState((state) => {
      if (state.activeJobId !== message.jobId || state.activeTaskType !== "scene") return;
      const job = state.jobs.find((entry) => entry.id === message.jobId);
      if (job) {
        job.status = "pending";
        job.stage = "사용자 중단";
        job.progress = 0;
      }
      state.activeJobId = null;
      state.activeTaskType = null;
      state.pauseRequested = false;
      state.status = "paused";
      state.nextRunAt = null;
    });
  }

  if (message.type === "FLOW_JOB_FAILED") {
    return scheduleSceneAutomaticRetry(String(message.error || "Flow 이미지 생성에 실패했습니다."), message.jobId);
  }

  if (message.type === "FLOW_CHARACTER_PAUSED") {
    await chrome.alarms.clear(QUEUE_ALARM);
    return updateState((state) => {
      if (state.activeJobId !== message.characterId || state.activeTaskType !== "character") return;
      const character = state.characters.find((entry) => entry.id === message.characterId);
      if (character) {
        character.status = "pending";
        character.stage = String(message.stage || "사용자 중단 · 다시 생성 대기");
        character.progress = 0;
        character.detectedImages = 0;
        character.referenceImages = 0;
        character.resultAssets = [];
        character.error = null;
      }
      state.activeJobId = null;
      state.activeTaskType = null;
      state.pauseRequested = false;
      state.status = "paused";
      state.nextRunAt = null;
    });
  }

  if (message.type === "FLOW_CHARACTER_FAILED") {
    return pauseWithError(String(message.error || "Flow 캐릭터 생성에 실패했습니다."), message.characterId, "character");
  }

  return null;
}

function broadcastDownloadProgress(phase, current, total, message) {
  chrome.runtime.sendMessage({
    type: "PROJECT_DOWNLOAD_PROGRESS",
    progress: { phase, current: Number(current || 0), total: Number(total || 0), message: String(message || "") }
  }).catch(() => {});
}

async function ensureArchiveDocument() {
  if (await chrome.offscreen.hasDocument()) return;
  await chrome.offscreen.createDocument({
    url: "offscreen.html",
    reasons: ["BLOBS"],
    justification: "Create one ZIP Blob URL so project images download as a single archive."
  });
}

async function buildProjectArchive(entries) {
  await ensureArchiveDocument();
  const response = await chrome.runtime.sendMessage({
    target: "offscreen",
    type: "BUILD_PROJECT_ARCHIVE",
    entries
  });
  if (!response?.ok) throw new Error(response?.error || "프로젝트 ZIP 파일을 만들지 못했습니다.");
  return requireArchiveResult(response.result);
}

async function downloadProject() {
  const current = await readState();
  if (current.activeJobId || ["running", "waiting", "pausing"].includes(current.status)) {
    throw new Error("실행 중인 큐를 먼저 중단하거나 완료한 뒤 프로젝트를 다운로드해 주세요.");
  }
  if (!current.jobs.length && !current.characters.length) {
    throw new Error("다운로드 순서를 만들 작업 목록이 없습니다. 프롬프트 분석 결과를 먼저 작업 큐에 적용해 주세요.");
  }

  const mainTab = await findFlowTab(current.tabId);
  if (!mainTab?.id) throw new Error("이미지를 가져올 Google Flow 프로젝트 탭이 없습니다.");
  downloadInProgress = true;
  syncPowerState(current);
  try {
    broadcastDownloadProgress("scanning", 0, 1, "Flow 모든 미디어 카드에서 원본 URL을 순서대로 수집하는 중");
    const scan = await sendToTab(mainTab.id, {
      type: "SCAN_FLOW_PROJECT_ASSETS",
      characterKeys: current.characters.map((character) => character.key)
    });
    if (!scan?.ready) throw new Error(scan?.error || "Flow 프로젝트의 이미지 URL을 수집하지 못했습니다.");

    const synchronizedState = await updateState((draft) => {
      const charactersByName = new Map(
        (scan.characterAssets || []).map((asset) => [String(asset.name || "").trim().toLowerCase(), asset])
      );
      for (const character of draft.characters) {
        const asset = charactersByName.get(String(character.key || "").trim().toLowerCase());
        if (asset) character.resultAssets = uniqueAssets([asset]);
      }
      draft.tabId = mainTab.id;
      draft.flowConnected = true;
      draft.lastFlowSceneImageCount = Array.isArray(scan.sceneAssets) ? scan.sceneAssets.length : null;
      draft.lastFlowImageSyncAt = Date.now();
    });

    const manifest = buildDownloadManifest({
      state: synchronizedState,
      projectTitle: scan.projectTitle,
      orderedSceneAssets: scan.sceneAssets || [],
      characterAssets: scan.characterAssets || []
    });
    if (!manifest.entries.length) throw new Error("Flow 모든 미디어에서 다운로드할 원본 이미지를 찾지 못했습니다.");
    broadcastDownloadProgress(
      "scanned",
      0,
      manifest.entries.length,
      `Flow 장면 ${manifest.scannedSceneCount}/${manifest.expectedSceneCount}장 · 캐릭터 ${manifest.entries.filter((entry) => entry.kind === "character").length}장 확인`
    );

    const archive = await buildProjectArchive(manifest.entries);
    const zipUrl = archive.url;
    const archiveFilename = `${manifest.folder}.zip`;
    broadcastDownloadProgress("downloading", archive.count, manifest.entries.length, "프로젝트 ZIP 파일 다운로드 요청 중");
    try {
      await chrome.downloads.download({
        url: zipUrl,
        filename: archiveFilename,
        saveAs: false,
        conflictAction: "uniquify"
      });
    } finally {
      chrome.runtime.sendMessage({ target: "offscreen", type: "REVOKE_PROJECT_ARCHIVE", url: zipUrl }).catch(() => {});
    }

    broadcastDownloadProgress("completed", archive.count, manifest.entries.length, `${archive.count}개 이미지를 ZIP 하나로 저장 요청 완료`);
    return {
      folder: manifest.folder,
      archiveFilename,
      downloaded: archive.count,
      total: manifest.entries.length,
      sceneCount: manifest.entries.filter((entry) => entry.kind === "scene").length,
      characterCount: manifest.entries.filter((entry) => entry.kind === "character").length,
      missingScenes: manifest.missingScenes,
      missingCharacters: manifest.missingCharacters,
      scannedSceneCount: manifest.scannedSceneCount,
      expectedSceneCount: manifest.expectedSceneCount,
      extraSceneCount: manifest.extraSceneCount,
      allMediaCount: Number(scan.allMediaCount || manifest.scannedSceneCount),
      removedCharacterMediaCount: Number(scan.removedCharacterMediaCount || 0),
      failures: []
    };
  } finally {
    downloadInProgress = false;
    syncPowerState(await readState().catch(() => current));
  }
}

async function handleUiMessage(message) {
  if (message.type === "GET_STATE") return readState();

  if (message.type === "DOWNLOAD_PROJECT") return downloadProject();

  if (message.type === "SET_QUEUE") {
    await chrome.alarms.clear(QUEUE_ALARM);
    return updateState((state) => {
      if (state.activeJobId) throw new Error("진행 중인 이미지 작업이 끝난 뒤 새 큐를 적용해 주세요.");
      const previousState = { characters: state.characters, jobs: state.jobs };
      const reuseExistingCharacters = Boolean(message.reuseExistingCharacters);
      const isIntroQueue = message.queueMode === "intro";
      const existingJobs = reuseExistingCharacters ? state.jobs.map((job) => ({ ...job })) : [];
      const existingMaximum = existingJobs.reduce((maximum, job, index) => Math.max(maximum, Number(job.number || index + 1)), 0);
      const queuedPrompts = (Array.isArray(message.prompts) ? message.prompts : []).map((prompt, index) => ({
        ...prompt,
        number: isIntroQueue ? existingMaximum + index + 1 : prompt.number,
        sourceMode: isIntroQueue ? prompt.sourceMode || "intro" : prompt.sourceMode || "scene"
      }));
      const jobs = [...existingJobs, ...createJobs(queuedPrompts)];
      const characters = reuseExistingCharacters
        ? state.characters.map((character) => ({ ...character }))
        : createCharacters(Array.isArray(message.characters) ? message.characters : [], {
          alreadyRegistered: Boolean(message.charactersAlreadyRegistered)
        });
      carryForwardCompletedTasks({ characters, jobs }, previousState);
      state.jobs = jobs;
      state.characters = characters;
      state.queueMode = isIntroQueue ? "intro" : "scene";
      state.lastFlowSceneImageCount = null;
      state.lastFlowImageSyncAt = null;
      state.status = "idle";
      state.phase = characters.some((character) => character.status === "pending") ? "characters" : "scenes";
      state.activeJobId = null;
      state.activeTaskType = null;
      state.nextRunAt = null;
      state.pauseRequested = false;
      state.manualPause = false;
      state.lastError = null;
    });
  }

  if (message.type === "SYNC_FLOW_STATE") {
    return synchronizeFlowCharacters();
  }

  if (message.type === "SET_CHARACTER_READY") {
    return updateState((state) => {
      if (state.activeJobId || ["running", "waiting", "pausing"].includes(state.status)) {
        throw new Error("실행 중인 큐를 먼저 중단한 뒤 시작 단계를 변경해 주세요.");
      }
      const ready = Boolean(message.ready);
      if (!setCharacterReady(state, String(message.characterId || ""), ready)) {
        throw new Error("상태를 변경할 캐릭터를 찾지 못했습니다.");
      }
      state.nextRunAt = null;
      state.pauseRequested = false;
      state.lastError = null;
      if (!ready) {
        state.phase = "characters";
        state.status = state.status === "idle" ? "idle" : "paused";
      } else if (state.characters.every((character) => character.status === "completed")) {
        state.phase = state.jobs.some((job) => job.status === "pending") ? "scenes" : "completed";
        if (state.status === "completed" && state.jobs.some((job) => job.status === "pending")) state.status = "paused";
      }
    });
  }

  if (message.type === "SET_JOB_READY") {
    return updateState((state) => {
      if (state.activeJobId || ["running", "waiting", "pausing"].includes(state.status)) {
        throw new Error("실행 중인 큐를 먼저 중단한 뒤 시작 단계를 변경해 주세요.");
      }
      const ready = Boolean(message.ready);
      if (!setJobReady(state, String(message.jobId || ""), ready)) {
        throw new Error("상태를 변경할 장면 작업을 찾지 못했습니다.");
      }
      state.nextRunAt = null;
      state.pauseRequested = false;
      state.lastError = null;
      if (!ready) {
        state.phase = state.characters.every((character) => character.status === "completed") ? "scenes" : "characters";
        state.status = state.status === "idle" ? "idle" : "paused";
      } else if (state.characters.every((character) => character.status === "completed")
        && state.jobs.every((job) => job.status === "completed")) {
        state.phase = "completed";
        state.status = "completed";
      }
    });
  }

  if (message.type === "UPDATE_OPTIONS") {
    return updateState((state) => {
      if (state.activeJobId) throw new Error("진행 중에는 생성 설정을 변경할 수 없습니다.");
      const previousModel = state.options.model;
      state.options = normalizeOptions({ ...state.options, ...message.options });
      if (state.options.model === previousModel) return;

      const quotaPattern = /(?:quota|limit|한도|다른\s*모델)/i;
      if (quotaPattern.test(String(state.lastError || ""))) state.lastError = null;
      for (const task of [...(state.characters || []), ...(state.jobs || [])]) {
        if (task.status !== "failed" || !quotaPattern.test(String(task.error || ""))) continue;
        task.stage = `${state.options.model}로 재시도 가능`;
        task.error = `${state.options.model}로 변경했습니다. 실패 작업 다시 실행을 눌러 주세요.`;
      }
    });
  }

  if (message.type === "START_QUEUE" || message.type === "RESUME_QUEUE") {
    const beforeSync = await readState();
    if (!beforeSync.activeJobId && beforeSync.characters.some((character) => character.status !== "completed")) {
      await synchronizeFlowCharacters();
    }
    const state = await updateState((draft) => {
      if (draft.activeJobId) return;
      if (!hasPendingTasks(draft)) throw new Error("실행할 대기 작업이 없습니다.");
      draft.status = "running";
      draft.pauseRequested = false;
      draft.manualPause = false;
      draft.lastError = null;
      draft.nextRunAt = null;
      draft.lastFlowSceneImageCount = null;
      draft.lastFlowImageSyncAt = null;
    });
    await chrome.alarms.clear(QUEUE_ALARM);
    void launchNextJob();
    return state;
  }

  if (message.type === "PAUSE_QUEUE") {
    const state = await updateState((draft) => {
      draft.manualPause = true;
      if (draft.activeJobId) {
        draft.pauseRequested = true;
        draft.status = "pausing";
      } else {
        draft.pauseRequested = false;
        draft.status = "paused";
        draft.nextRunAt = null;
      }
    });
    await chrome.alarms.clear(QUEUE_ALARM);
    if (state.activeJobId && state.tabId) {
      sendToTab(state.tabId, {
        type: "PAUSE_FLOW_TASK",
        taskId: state.activeJobId,
        taskType: state.activeTaskType
      }).catch(() => {});
    }
    return state;
  }

  if (message.type === "RETRY_FAILED") {
    return updateState((state) => {
      if (state.activeJobId) throw new Error("현재 생성이 끝난 뒤 재시도해 주세요.");
      if (!retryFailedTasks(state)) throw new Error("재시도할 실패 작업이 없습니다.");
    });
  }

  if (message.type === "RETRY_CHARACTER") {
    return updateState((state) => {
      const characterId = String(message.characterId || "");
      const character = state.characters.find((entry) => entry.id === characterId);
      if (state.activeJobId && !(state.activeJobId === characterId && character?.status === "review")) {
        throw new Error("현재 생성이 끝난 뒤 재시도해 주세요.");
      }
      if (character?.status === "review") {
        setCharacterReady(state, characterId, false, "재생성 대기");
        state.status = "paused";
        state.phase = "characters";
        state.activeJobId = null;
        state.activeTaskType = null;
        state.nextRunAt = null;
        state.pauseRequested = false;
        state.lastError = null;
        return;
      }
      if (!retryFailedTasks(state, { characterId, jobId: "__none__" })) {
        throw new Error("재시도할 실패 캐릭터를 찾지 못했습니다.");
      }
    });
  }

  if (message.type === "CONFIRM_CHARACTER") {
    const current = await readState();
    if (current.activeTaskType !== "character" || current.activeJobId !== message.characterId) {
      throw new Error("등록 확인을 기다리는 캐릭터가 없습니다.");
    }
    const character = current.characters.find((entry) => entry.id === message.characterId);
    if (character?.status !== "review") throw new Error("이 캐릭터는 수동 확인 상태가 아닙니다.");
    return completeTask(message.characterId, "character", character.detectedImages || 1);
  }

  if (message.type === "REMOVE_JOB") {
    return updateState((state) => {
      if (state.activeJobId) throw new Error("진행 중에는 작업을 삭제할 수 없습니다.");
      state.jobs = state.jobs
        .filter((job) => job.id !== message.jobId)
        .map((job, index) => ({ ...job, index }));
      if (!state.jobs.length) state.status = "idle";
    });
  }

  if (message.type === "RESET_QUEUE") {
    await chrome.alarms.clear(QUEUE_ALARM);
    return updateState((state) => {
      if (state.activeJobId) throw new Error("현재 생성이 끝난 뒤 큐를 초기화해 주세요.");
      const fresh = createInitialState();
      fresh.options = state.options;
      fresh.tabId = state.tabId;
      fresh.pageSessionId = state.pageSessionId;
      fresh.flowConnected = state.flowConnected;
      Object.assign(state, fresh);
    });
  }

  if (message.type === "OPEN_FLOW") {
    const state = await readState();
    const existing = await findFlowTab(state.tabId);
    if (existing?.id) {
      await chrome.tabs.update(existing.id, { active: true });
      if (existing.windowId) await chrome.windows.update(existing.windowId, { focused: true });
      return { opened: true, tabId: existing.id };
    }
    const tab = await chrome.tabs.create({ url: "https://labs.google/fx/tools/flow/" });
    return { opened: true, tabId: tab.id };
  }

  if (message.type === "CHECK_FLOW") {
    const state = await readState();
    const tab = await findFlowTab(state.tabId);
    if (!tab?.id) return { connected: false, error: "열린 Flow 프로젝트 탭이 없습니다." };
    try {
      const diagnostics = await sendToTab(tab.id, { type: "GET_FLOW_DIAGNOSTICS" });
      await updateState((draft) => {
        draft.tabId = tab.id;
        draft.flowConnected = Boolean(diagnostics?.ready);
      });
      return { connected: Boolean(diagnostics?.ready), tabId: tab.id, diagnostics };
    } catch (error) {
      return { connected: false, error: String(error?.message || error) };
    }
  }

  throw new Error(`지원하지 않는 메시지입니다: ${message.type}`);
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message?.type || message.target === "offscreen" || message.type === "STATE_UPDATED" || message.type === "PROJECT_DOWNLOAD_PROGRESS") return false;
  const isFlowEvent = message.type.startsWith("FLOW_");
  const handler = isFlowEvent ? handleFlowEvent(message, sender) : handleUiMessage(message);
  Promise.resolve(handler)
    .then((result) => sendResponse({ ok: true, result }))
    .catch((error) => sendResponse({ ok: false, error: String(error?.message || error) }));
  return true;
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name !== QUEUE_ALARM) return;
  void updateState((state) => {
    if (state.status !== "waiting" || state.activeJobId) return;
    state.status = "running";
    state.nextRunAt = null;
  }).then(() => launchNextJob());
});

async function recoverQueue() {
  const state = await readState();
  syncPowerState(state);
  if (state.status === "paused" && !state.manualPause && !state.activeJobId) {
    const retryableFailure = state.jobs.find((job) => job.status === "failed" && !isBlockingFlowError(job.error));
    if (retryableFailure) {
      await scheduleSceneAutomaticRetry(retryableFailure.error || "중단된 장면 작업을 자동 복구합니다.", retryableFailure.id);
      return;
    }
  }
  if (state.status === "waiting" && state.nextRunAt) {
    if (state.nextRunAt > Date.now()) {
      await chrome.alarms.create(QUEUE_ALARM, { when: state.nextRunAt });
    } else {
      await updateState((draft) => {
        draft.status = "running";
        draft.nextRunAt = null;
      });
      void launchNextJob();
    }
  } else if (state.status === "running" && !state.activeJobId) {
    void launchNextJob();
  }
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
  void recoverQueue();
});

chrome.runtime.onStartup.addListener(() => {
  void recoverQueue();
});

void recoverQueue();
